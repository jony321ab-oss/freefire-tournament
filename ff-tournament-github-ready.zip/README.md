# Free Fire Tournament Platform, Stage 1

Shared Flutter core, Supabase schema, RLS, and two app shells (Player and Admin).
See the setup section in the chat for the step-by-step instructions.
