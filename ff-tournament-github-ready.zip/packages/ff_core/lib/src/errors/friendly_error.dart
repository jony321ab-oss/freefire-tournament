import 'package:supabase_flutter/supabase_flutter.dart';

/// Maps any thrown error to a message that is safe to show to a user.
String friendlyError(Object error) {
  if (error is AuthException) {
    final msg = error.message.toLowerCase();
    if (msg.contains('invalid login')) return 'Wrong email or password.';
    if (msg.contains('already registered')) return 'That email is already registered.';
    return 'Sign-in failed. Please try again.';
  }
  if (error is PostgrestException) {
    if (error.code == '42501') return 'You do not have permission to do that.';
    if (error.message.contains('Registration')) return error.message;
    if (error.message.contains('full')) return 'This tournament is full.';
    return 'Something went wrong on the server. Please try again.';
  }
  return 'Something went wrong. Please check your connection and try again.';
}
