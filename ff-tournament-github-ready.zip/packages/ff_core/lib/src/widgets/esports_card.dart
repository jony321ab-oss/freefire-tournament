import 'package:flutter/material.dart';

import '../theme/app_colors.dart';

class EsportsCard extends StatelessWidget {
  const EsportsCard({
    super.key,
    required this.child,
    this.onTap,
    this.accent = AppColors.neon,
    this.padding = const EdgeInsets.all(16),
  });

  final Widget child;
  final VoidCallback? onTap;
  final Color accent;
  final EdgeInsetsGeometry padding;

  @override
  Widget build(BuildContext context) {
    final content = Container(
      padding: padding,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(16),
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [accent.withValues(alpha: 0.10), AppColors.surface],
        ),
        border: Border.all(color: accent.withValues(alpha: 0.35)),
      ),
      child: child,
    );

    if (onTap == null) return content;
    return InkWell(
      borderRadius: BorderRadius.circular(16),
      onTap: onTap,
      child: content,
    );
  }
}
