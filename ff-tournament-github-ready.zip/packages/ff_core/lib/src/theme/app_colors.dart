import 'package:flutter/material.dart';

abstract final class AppColors {
  static const Color background = Color(0xFF07090F);
  static const Color surface = Color(0xFF0E1320);
  static const Color surfaceElevated = Color(0xFF151C2E);
  static const Color border = Color(0xFF243049);

  static const Color neon = Color(0xFFFF6A2B);
  static const Color neonSoft = Color(0xFFFF9A5C);
  static const Color cyan = Color(0xFF30E0FF);
  static const Color gold = Color(0xFFFFC857);

  static const Color textPrimary = Color(0xFFF2F5FA);
  static const Color textSecondary = Color(0xFF9AA6BD);
  static const Color textMuted = Color(0xFF5E6B85);

  static const Color success = Color(0xFF2ED47A);
  static const Color warning = Color(0xFFFFB020);
  static const Color danger = Color(0xFFFF4D5E);
}
