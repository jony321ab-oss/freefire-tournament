import 'dart:convert';

class AppEnv {
  AppEnv._();

  static const String supabaseUrl = String.fromEnvironment('SUPABASE_URL');
  static const String supabaseAnonKey = String.fromEnvironment('SUPABASE_ANON_KEY');

  static void validate() {
    if (supabaseUrl.isEmpty || supabaseAnonKey.isEmpty) {
      throw StateError(
        'Missing SUPABASE_URL or SUPABASE_ANON_KEY. '
        'Pass them with --dart-define at build time.',
      );
    }
    assertSafeKey(supabaseAnonKey);
  }

  static void assertSafeKey(String key) {
    if (roleFromJwt(key) == 'service_role') {
      throw StateError(
        'Refusing to start: a service_role key was supplied. '
        'Only the public anon key may be shipped in a client app.',
      );
    }
  }

  static String? roleFromJwt(String token) {
    try {
      final parts = token.split('.');
      if (parts.length != 3) return null;
      final payload = jsonDecode(
        utf8.decode(base64Url.decode(base64Url.normalize(parts[1]))),
      );
      if (payload is Map<String, dynamic>) {
        return payload['role'] as String?;
      }
      return null;
    } catch (_) {
      return null;
    }
  }
}
