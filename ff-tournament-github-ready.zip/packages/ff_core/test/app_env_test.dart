import 'dart:convert';

import 'package:ff_core/ff_core.dart';
import 'package:flutter_test/flutter_test.dart';

String _fakeJwt(String role) {
  String seg(Map<String, dynamic> m) =>
      base64Url.encode(utf8.encode(jsonEncode(m))).replaceAll('=', '');
  return '${seg({'alg': 'HS256'})}.${seg({'role': role})}.signature';
}

void main() {
  test('anon key is accepted', () {
    expect(() => AppEnv.assertSafeKey(_fakeJwt('anon')), returnsNormally);
  });

  test('service_role key is rejected', () {
    expect(() => AppEnv.assertSafeKey(_fakeJwt('service_role')), throwsStateError);
  });

  test('non-JWT string does not crash the guard', () {
    expect(AppEnv.roleFromJwt('not-a-jwt'), isNull);
  });
}
