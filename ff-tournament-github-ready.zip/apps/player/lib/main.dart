import 'package:ff_core/ff_core.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await SupabaseBootstrap.init();
  runApp(const ProviderScope(child: PlayerApp()));
}

class PlayerApp extends StatelessWidget {
  const PlayerApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'FF Tournament',
      debugShowCheckedModeBanner: false,
      theme: AppTheme.dark(),
      home: const _StageOneStatus(),
    );
  }
}

class _StageOneStatus extends StatelessWidget {
  const _StageOneStatus();

  @override
  Widget build(BuildContext context) {
    final signedIn = SupabaseBootstrap.client.auth.currentSession != null;
    return Scaffold(
      appBar: AppBar(title: const Text('PLAYER')),
      body: Center(
        child: EsportsCard(
          child: Text(
            'Stage 1 foundation OK\n'
            'Session: ${signedIn ? "signed in" : "anonymous"}',
            textAlign: TextAlign.center,
          ),
        ),
      ),
    );
  }
}
