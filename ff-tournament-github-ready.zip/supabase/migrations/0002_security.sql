-- 0002_security.sql
create or replace function public.is_admin()
returns boolean language sql stable security definer set search_path = public as $$
  select exists (
    select 1 from public.profiles p
    where p.id = auth.uid() and p.role = 'admin' and not p.is_banned
  );
$$;

create or replace function public.is_tournament_visible(t_id uuid)
returns boolean language sql stable security definer set search_path = public as $$
  select exists (
    select 1 from public.tournaments t
    where t.id = t_id and t.status <> 'draft'
  );
$$;

create or replace function public.is_approved_participant(t_id uuid)
returns boolean language sql stable security definer set search_path = public as $$
  select exists (
    select 1 from public.registrations r
    where r.tournament_id = t_id and r.user_id = auth.uid() and r.status = 'approved'
  );
$$;

revoke all on function public.is_admin() from public;
revoke all on function public.is_tournament_visible(uuid) from public;
revoke all on function public.is_approved_participant(uuid) from public;
grant execute on function public.is_admin() to authenticated;
grant execute on function public.is_tournament_visible(uuid) to authenticated;
grant execute on function public.is_approved_participant(uuid) to authenticated;

create or replace function public.guard_profile_privileges()
returns trigger language plpgsql security definer set search_path = public as $$
begin
  if auth.uid() is not null and not public.is_admin() then
    if new.id is distinct from old.id
       or new.role is distinct from old.role
       or new.is_banned is distinct from old.is_banned then
      raise exception 'Not allowed to change role or ban status'
        using errcode = '42501';
    end if;
  end if;
  return new;
end $$;

create trigger profiles_guard before update on public.profiles
  for each row execute function public.guard_profile_privileges();

create or replace function public.guard_registration()
returns trigger language plpgsql security definer set search_path = public as $$
declare
  t record;
  approved_count int;
  player_banned boolean;
begin
  if tg_op = 'INSERT' then
    select is_banned into player_banned from public.profiles where id = new.user_id;
    if player_banned then
      raise exception 'Account is restricted';
    end if;

    select * into t from public.tournaments where id = new.tournament_id for update;
    if t.status <> 'open' then
      raise exception 'Registration is not open for this tournament';
    end if;
    if (t.registration_opens_at is not null and now() < t.registration_opens_at)
       or (t.registration_closes_at is not null and now() > t.registration_closes_at) then
      raise exception 'Registration window is closed';
    end if;

    new.status := 'pending';
    new.reviewed_by := null;
    new.reviewed_at := null;
    new.rejection_reason := null;
  end if;

  if tg_op = 'UPDATE' and new.status is distinct from old.status then
    select * into t from public.tournaments where id = new.tournament_id for update;

    if new.status = 'approved' then
      select count(*) into approved_count
      from public.registrations
      where tournament_id = new.tournament_id and status = 'approved' and id <> new.id;
      if approved_count >= t.max_teams then
        raise exception 'Tournament is full';
      end if;
    end if;

    new.reviewed_by := auth.uid();
    new.reviewed_at := now();
  end if;

  return new;
end $$;

create trigger registrations_guard
  before insert or update on public.registrations
  for each row execute function public.guard_registration();

create or replace function public.guard_match_result()
returns trigger language plpgsql security definer set search_path = public as $$
begin
  if not exists (
    select 1
    from public.matches m
    join public.registrations r on r.tournament_id = m.tournament_id
    where m.id = new.match_id and r.id = new.registration_id and r.status = 'approved'
  ) then
    raise exception 'Result must reference an approved participant of the same tournament';
  end if;
  return new;
end $$;

create trigger match_results_guard
  before insert or update on public.match_results
  for each row execute function public.guard_match_result();

alter table public.profiles          enable row level security;
alter table public.tournaments       enable row level security;
alter table public.registrations     enable row level security;
alter table public.matches           enable row level security;
alter table public.room_credentials  enable row level security;
alter table public.match_results     enable row level security;
alter table public.notices           enable row level security;
alter table public.support_tickets   enable row level security;

revoke all on all tables in schema public from anon;

grant select, update on public.profiles to authenticated;
create policy profiles_select on public.profiles for select to authenticated
  using (id = auth.uid() or public.is_admin());
create policy profiles_update_own on public.profiles for update to authenticated
  using (id = auth.uid() or public.is_admin())
  with check (id = auth.uid() or public.is_admin());

grant select, insert, update, delete on public.tournaments to authenticated;
create policy tournaments_select on public.tournaments for select to authenticated
  using (public.is_admin() or status <> 'draft');
create policy tournaments_admin_write on public.tournaments for all to authenticated
  using (public.is_admin()) with check (public.is_admin());

grant select, insert, delete, update on public.registrations to authenticated;
create policy registrations_select on public.registrations for select to authenticated
  using (user_id = auth.uid() or public.is_admin());
create policy registrations_insert_own on public.registrations for insert to authenticated
  with check (user_id = auth.uid() and status = 'pending');
create policy registrations_withdraw_pending on public.registrations for delete to authenticated
  using ((user_id = auth.uid() and status = 'pending') or public.is_admin());
create policy registrations_admin_update on public.registrations for update to authenticated
  using (public.is_admin()) with check (public.is_admin());

grant select, insert, update, delete on public.matches to authenticated;
create policy matches_select on public.matches for select to authenticated
  using (public.is_admin() or public.is_tournament_visible(tournament_id));
create policy matches_admin_write on public.matches for all to authenticated
  using (public.is_admin()) with check (public.is_admin());

grant select, insert, update, delete on public.room_credentials to authenticated;
create policy room_credentials_participant_read on public.room_credentials for select to authenticated
  using (
    public.is_admin()
    or (
      now() >= release_at
      and exists (
        select 1 from public.matches m
        where m.id = room_credentials.match_id
          and public.is_approved_participant(m.tournament_id)
      )
    )
  );
create policy room_credentials_admin_write on public.room_credentials for all to authenticated
  using (public.is_admin()) with check (public.is_admin());

grant select, insert, update, delete on public.match_results to authenticated;
create policy match_results_select on public.match_results for select to authenticated
  using (
    public.is_admin()
    or exists (
      select 1 from public.matches m
      where m.id = match_results.match_id
        and m.status = 'completed'
        and public.is_tournament_visible(m.tournament_id)
    )
  );
create policy match_results_admin_write on public.match_results for all to authenticated
  using (public.is_admin()) with check (public.is_admin());

grant select, insert, update, delete on public.notices to authenticated;
create policy notices_select on public.notices for select to authenticated
  using (
    public.is_admin()
    or (
      published_at <= now()
      and (tournament_id is null or public.is_tournament_visible(tournament_id))
    )
  );
create policy notices_admin_write on public.notices for all to authenticated
  using (public.is_admin()) with check (public.is_admin());

grant select, insert, update on public.support_tickets to authenticated;
create policy tickets_select on public.support_tickets for select to authenticated
  using (user_id = auth.uid() or public.is_admin());
create policy tickets_insert_own on public.support_tickets for insert to authenticated
  with check (user_id = auth.uid() and status = 'open');
create policy tickets_admin_update on public.support_tickets for update to authenticated
  using (public.is_admin()) with check (public.is_admin());
