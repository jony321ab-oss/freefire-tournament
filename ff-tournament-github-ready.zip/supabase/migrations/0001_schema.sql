-- 0001_schema.sql
create extension if not exists pgcrypto;

create type public.user_role           as enum ('player', 'admin');
create type public.tournament_status   as enum ('draft', 'open', 'closed', 'live', 'completed', 'cancelled');
create type public.registration_status as enum ('pending', 'approved', 'rejected');
create type public.match_status        as enum ('scheduled', 'live', 'completed', 'cancelled');
create type public.ticket_status       as enum ('open', 'answered', 'closed');

create or replace function public.set_updated_at()
returns trigger language plpgsql as $$
begin
  new.updated_at := now();
  return new;
end $$;

create table public.profiles (
  id           uuid primary key references auth.users(id) on delete cascade,
  username     text not null unique check (username ~ '^[A-Za-z0-9_]{3,20}$'),
  display_name text not null check (char_length(display_name) between 2 and 40),
  ff_uid       text not null check (ff_uid ~ '^[0-9]{6,12}$'),
  role         public.user_role not null default 'player',
  is_banned    boolean not null default false,
  created_at   timestamptz not null default now(),
  updated_at   timestamptz not null default now()
);
create trigger profiles_updated_at before update on public.profiles
  for each row execute function public.set_updated_at();

create table public.tournaments (
  id                       uuid primary key default gen_random_uuid(),
  title                    text not null check (char_length(title) between 3 and 80),
  description              text check (char_length(description) <= 2000),
  mode                     text not null check (mode in ('solo', 'duo', 'squad')),
  max_teams                int  not null check (max_teams between 2 and 500),
  registration_opens_at    timestamptz,
  registration_closes_at   timestamptz,
  starts_at                timestamptz not null,
  status                   public.tournament_status not null default 'draft',
  created_by               uuid references public.profiles(id) on delete set null,
  created_at               timestamptz not null default now(),
  updated_at               timestamptz not null default now(),
  constraint registration_window_valid check (
    registration_opens_at is null or registration_closes_at is null
    or registration_closes_at > registration_opens_at
  )
);
create trigger tournaments_updated_at before update on public.tournaments
  for each row execute function public.set_updated_at();
create index tournaments_status_idx on public.tournaments (status, starts_at);

create table public.registrations (
  id               uuid primary key default gen_random_uuid(),
  tournament_id    uuid not null references public.tournaments(id) on delete cascade,
  user_id          uuid not null references public.profiles(id) on delete cascade,
  team_name        text check (team_name is null or char_length(team_name) between 2 and 40),
  status           public.registration_status not null default 'pending',
  reviewed_by      uuid references public.profiles(id) on delete set null,
  reviewed_at      timestamptz,
  rejection_reason text check (char_length(rejection_reason) <= 300),
  created_at       timestamptz not null default now(),
  updated_at       timestamptz not null default now(),
  unique (tournament_id, user_id)
);
create trigger registrations_updated_at before update on public.registrations
  for each row execute function public.set_updated_at();
create index registrations_user_idx on public.registrations (user_id);
create index registrations_tournament_status_idx on public.registrations (tournament_id, status);

create table public.matches (
  id            uuid primary key default gen_random_uuid(),
  tournament_id uuid not null references public.tournaments(id) on delete cascade,
  round_number  int  not null check (round_number between 1 and 20),
  name          text not null check (char_length(name) between 2 and 60),
  scheduled_at  timestamptz not null,
  status        public.match_status not null default 'scheduled',
  created_at    timestamptz not null default now(),
  unique (tournament_id, round_number)
);
create index matches_tournament_idx on public.matches (tournament_id, scheduled_at);

create table public.room_credentials (
  match_id      uuid primary key references public.matches(id) on delete cascade,
  room_id       text not null check (char_length(room_id) between 1 and 32),
  room_password text not null check (char_length(room_password) between 1 and 32),
  release_at    timestamptz not null,
  published_by  uuid references public.profiles(id) on delete set null,
  published_at  timestamptz not null default now()
);

create table public.match_results (
  id              uuid primary key default gen_random_uuid(),
  match_id        uuid not null references public.matches(id) on delete cascade,
  registration_id uuid not null references public.registrations(id) on delete cascade,
  placement       int  not null check (placement between 1 and 500),
  kills           int  not null default 0 check (kills between 0 and 500),
  points          int  not null default 0 check (points between 0 and 1000),
  created_at      timestamptz not null default now(),
  unique (match_id, registration_id),
  unique (match_id, placement)
);

create table public.notices (
  id            uuid primary key default gen_random_uuid(),
  tournament_id uuid references public.tournaments(id) on delete cascade,
  title         text not null check (char_length(title) between 3 and 120),
  body          text not null check (char_length(body) between 1 and 5000),
  published_at  timestamptz not null default now(),
  created_by    uuid references public.profiles(id) on delete set null,
  created_at    timestamptz not null default now()
);
create index notices_published_idx on public.notices (published_at desc);

create table public.support_tickets (
  id          uuid primary key default gen_random_uuid(),
  user_id     uuid not null references public.profiles(id) on delete cascade,
  subject     text not null check (char_length(subject) between 3 and 120),
  message     text not null check (char_length(message) between 1 and 3000),
  status      public.ticket_status not null default 'open',
  admin_reply text check (char_length(admin_reply) <= 3000),
  created_at  timestamptz not null default now(),
  updated_at  timestamptz not null default now()
);
create trigger support_tickets_updated_at before update on public.support_tickets
  for each row execute function public.set_updated_at();

create or replace function public.handle_new_user()
returns trigger language plpgsql security definer set search_path = public as $$
begin
  insert into public.profiles (id, username, display_name, ff_uid)
  values (
    new.id,
    new.raw_user_meta_data->>'username',
    new.raw_user_meta_data->>'display_name',
    new.raw_user_meta_data->>'ff_uid'
  );
  return new;
end $$;

create trigger on_auth_user_created
  after insert on auth.users
  for each row execute function public.handle_new_user();
