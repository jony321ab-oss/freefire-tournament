-- 0003_views.sql
create or replace view public.tournament_leaderboard as
select
  r.tournament_id,
  r.id                                       as registration_id,
  coalesce(r.team_name, p.display_name)      as team_name,
  count(mr.id)                               as matches_played,
  coalesce(sum(mr.kills), 0)                 as total_kills,
  coalesce(sum(mr.points), 0)                as total_points
from public.registrations r
join public.profiles p on p.id = r.user_id
left join public.match_results mr on mr.registration_id = r.id
where r.status = 'approved'
group by r.tournament_id, r.id, r.team_name, p.display_name;

revoke all on public.tournament_leaderboard from anon;
grant select on public.tournament_leaderboard to authenticated;
