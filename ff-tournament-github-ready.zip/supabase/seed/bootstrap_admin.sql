-- Run in the Supabase SQL editor AFTER creating the admin account via sign-up.
-- Replace the UUID with the id from Authentication > Users.
update public.profiles
set role = 'admin'
where id = '00000000-0000-0000-0000-000000000000';
